//
//  folder.h
//  dynamicTable
//
//  Created by pcs20 on 10/1/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface folder : NSObject

@property(nonatomic,strong)NSString *folderName;

@end
